package test_p25;

public class Sample7 {

	public static void main(String[] args) {
		int fig;
		fig = 3;
		System.out.println("�ܼ�fig���ȬO"+fig);
	}

}
