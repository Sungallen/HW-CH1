package test_p31;

public class Sample11 {
	public static void main(String[] args) {
		System.out.println("1+2 ="+(1+2));
		System.out.println("3+4 ="+(3+4));
		
		int fig1 = 3;
		int fig2 = 4;
		int sum = fig1 + fig2;
		System.out.println("�ܼ�fig1����"+fig1);
		System.out.println("�ܼ�fig2����"+fig2);
		System.out.println("fig1 + fig2���ȬO"+sum);
		
		fig1 = fig1*2;
		System.out.println("�ܼ�fig1���⭿"+fig1);
	}
}
