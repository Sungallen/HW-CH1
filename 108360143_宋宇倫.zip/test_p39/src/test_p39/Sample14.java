package test_p39;

public class Sample14 {

	public static void main(String[] args) {
		int length = 5;
		double width = 3.3;
		System.out.println("����"+length);
		System.out.println("�e��"+width);
		System.out.println("���n��"+length * width);
		
		int fig1 = 8;
		int fig2 = 7;
		
		double div1 = fig1 / fig2;
		double div2 = (double)fig1 / (double)fig2;
		System.out.println("8/7 = "+ div1);
		System.out.println("8/7 = "+ div2);
	}

}
