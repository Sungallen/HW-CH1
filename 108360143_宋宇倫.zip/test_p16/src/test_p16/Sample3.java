package test_p16;

public class Sample3 {

	public static void main(String[] args) {
		System.out.println("A");
		System.out.println("�w��ϥ�Java");
		System.out.println(123);
	}

}
